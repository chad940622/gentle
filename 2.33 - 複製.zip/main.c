/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
  
  double distance, gas_price, gas_mileage, parking_fee, toll_fee;

  
  printf("請輸入您一整天的總里程數（公里）：");
  scanf("%lf", &distance);
  printf("請輸入汽油一公升多少錢（元）：");
  scanf("%lf", &gas_price);
  printf("請輸入平均一公升能行駛多少公里（公里/公升）：");
  scanf("%lf", &gas_mileage);
  printf("請輸入一天的停車費（元）：");
  scanf("%lf", &parking_fee);
  printf("請輸入一天的通行費（元）：");
  scanf("%lf", &toll_fee);

 
  double cost = (distance / gas_mileage) * gas_price + parking_fee + toll_fee;


  printf("您一天開車去工作的花費為：%f元\n", cost);

  return 0;
}