/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int rows=5;
int cols=9;
int main()
{
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            if (i==0|i==4)
                printf("H");
            else if(i==1|i==3){
                if(j==4)
                    printf("H");
                else
                    printf(" ");
            }
            if (i==2){
                if(j==4)
                    printf("H");
                else
                    printf(" ");
            }
            
        }
        printf("\n");
    }
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            if (i==0)
                {
                    if(j==2|j==8)
                printf("y");
                else printf(" ");
                }
            else if(i==1){
                if(j==3|j==7)
                    printf("y");
                else
                    printf(" ");
            }
            else if(i==2)
                {if(j==4|j==6)
                    printf("y");
                    else
                    printf(" ");
                }
            else if(i==3)
            {if(j==5)
                    printf("y");
                    else
                    printf(" ");
            }
                
            if (i==4){
                if(j==6|j==7|j==8)
                    printf("y");
                else
                    printf(" ");
            }
            
        }
        printf("\n");
    }
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            if (i==0)
                {
                    if(j==4)
                printf("c");
                else printf(" ");
                }
            else if(i==1){
                if(j==3|j==5)
                    printf("c");
                else
                    printf(" ");
            }
            else if(i==2)
                {if(j==2|j==6)
                    printf("c");
                    else
                    printf(" ");
                }
            else if(i==3|i==4)
            {if(j==2|j==7)
                    printf("c");
                    else
                    printf(" ");
            }
                
            
        }
        printf("\n");
    }
}
